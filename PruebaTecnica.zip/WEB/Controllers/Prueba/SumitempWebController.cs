﻿using Microsoft.AspNetCore.Mvc;

namespace WEB.Controllers.Prueba
{
    public class SumitempWebController : Controller
    {
        public IActionResult Sumitemp()
        {
            return View();
        }
    }
}
