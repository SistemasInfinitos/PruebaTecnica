# Support <!-- {docsify-ignore} -->
autoComplete.js has a great community make sure to reach out to them though the right channel

***

## Technical

For technical questions and support, please post your question on Stack Overflow using the below tag

- Stack Overflow [autoCompletejs][stackOverflow]

***

## General

For general questions or new ideas for `autoComplete.js` please start a discussion on Github using the below link

- Github [Discussions]

<!-- section links -->
[stackOverflow]: https://stackoverflow.com/questions/tagged/autoCompletejs
[Discussions]: https://github.com/TarekRaafat/autoComplete.js/discussions