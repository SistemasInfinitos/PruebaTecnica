# Getting Started <!-- {docsify-ignore} -->

This quick start is intended for beginner to advanced developers

***

## Quick Start <!-- {docsify-ignore} -->

It's very easy to get started with `autoComplete.js`.

All that's required is including an `<input>` or `<textarea>` or even any html tag with `contenteditable`attribute and  identifier, adding the `autoComplete.js` library script, and add `autoComplete.js` configured instance to your page in **3 easy steps**.

![autoComplete.js Code Example](./img/autoComplete.init.png "autoComplete.js Code Example")

Continue for installation guide.