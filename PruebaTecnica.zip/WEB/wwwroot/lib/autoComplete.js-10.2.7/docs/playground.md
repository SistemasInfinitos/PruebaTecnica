# Playground <!-- {docsify-ignore} -->

Live Demo Example

***

## CodePen

```iframe
height="600"
width="100%"
scrolling="no"
title="autoComplete.js"
src="https://codepen.io/tarekraafat/embed/rQopdW?height=265&theme-id=dark&default-tab=js,result"
frameborder="no"
loading="lazy"
allowtransparency="true"
allowfullscreen="true"
textContent="See the Pen <a href='https://codepen.io/tarekraafat/pen/rQopdW'>autoComplete.js</a> by Tarek Raafat (<a href='https://codepen.io/tarekraafat'>@tarekraafat</a>) on <a href='https://codepen.io'>CodePen</a>."
```