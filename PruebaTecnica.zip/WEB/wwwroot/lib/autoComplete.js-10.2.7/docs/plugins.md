# Plugins <!-- {docsify-ignore} -->

Add functionality and customize your autoComplete.js with plugins built by our amazing developer community

***

## Community Plugins

-   [Contao autoComplete.js Bundle](https://github.com/heimrichhannot/contao-autocompletejs-bundle) by [@heimrichhannot](https://github.com/heimrichhannot)